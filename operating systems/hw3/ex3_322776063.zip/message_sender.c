
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <stdio.h>

#include "message_slot.h"


int main(int argc, char *argv[])
{
    int fd,channel,content,len;
    if (argc != 4)
    {
        perror("MISSING ARGUMENTS\n");
        exit(1);
    }
    len = strlen(argv[3]);

    fd = open(argv[1], O_WRONLY);
    if(fd < 0)
    {
        perror("COULDN'T OPEN FILE!\n");
        exit(1);
    }
    channel = atoi(argv[2]);
    content = ioctl(fd, MSG_SLOT_CHANNEL, channel);
    if(content < 0)
    {
        close(fd);
        exit(1);
    }
    content = write(fd, argv[3], len);
    if(content < 0)
    {
        perror("WRITING FAILED\n");
        close(fd);
        exit(1);
    }
    close(fd);
    exit(0);
}
