#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include "message_slot.h"

int main(int argc, char *argv[])
{
    int fd,channel_id,read_content;
    char buffer[BUFFER_SIZE];

    if (argc != 3)
    {
        perror("MISSING ARGUMENTS!\n");
        exit(1);
    }
    fd=open(argv[1], O_RDONLY);
    if(fd < 0)
    {
        perror("FAILED OPENING FILE \n");
        exit(1);
    }
    channel_id = atoi(argv[2]);//set the octal number
    read_content = ioctl(fd, MSG_SLOT_CHANNEL, channel_id);
    if(read_content < 0)
    {
        close(fd);
        exit(1);
    }
    read_content = read(fd, buffer, 128);
    if (read_content < 0)
    {
        perror("READING FAILED\n");
        close(fd);
        exit(1);
    }
    close(fd);
    if(write(1, buffer, read_content) == -1)
    {
        exit(1);
    }
    exit(0);


}