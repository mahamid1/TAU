#undef __KERNEL__
#define __KERNEL__
#undef __MODULE__
#define __MODULE__


#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/string.h>
#include <linux/slab.h>
#include <linux/list.h>
#include <linux/types.h>
#include "message_slot.h"

MODULE_LICENSE("GPL");
static int device_open(struct inode* inode, struct file* file);
static ssize_t device_read(struct file* file, char __user* buffer, size_t length, loff_t* offset);
static long device_ioctl(struct file* file, unsigned int ioctl_command_id,unsigned long ioctl_param);
static ssize_t device_write (struct file* file , const char __user* buffer, size_t length, loff_t* offset);

struct file_operations Fops =
        {
                .owner          = THIS_MODULE,
                .read           = device_read,
                .write          = device_write,
                .open           = device_open,
                .unlocked_ioctl = device_ioctl,
        };

typedef struct chardev_info{spinlock_t lock; } chardev_info;
static struct chardev_info device_info;

static device_file* all_devices=NULL;

void free_all_devices(void) {
    device_file *curr_device;
    device_file *tmp_device;
    channel *curr_channel;
    channel *tmp_channel;
    curr_device = all_devices;
    while(curr_device!=NULL) {
        tmp_device = curr_device->next_device_file;
        curr_channel = curr_device->channels;
        while(curr_channel!=NULL) {
            tmp_channel = curr_channel->next;
            kfree(curr_channel);
            curr_channel = tmp_channel;
        }
        kfree(curr_device);
        curr_device = tmp_device;
    }
}


device_file* init_device(unsigned int minor) {
    device_file *device1;
    device1 = (device_file*)kmalloc(sizeof(device_file), GFP_KERNEL);
    if(device1==NULL) return NULL;
    device1->minor=minor;
    device1->channels=NULL;
    device1->next_device_file=NULL;
    return device1;
}
channel* init_channel(unsigned int channel_id ){
    channel *channel1;
    channel1 = (channel*) kmalloc(sizeof (channel),GFP_KERNEL);
    if(channel1==NULL) return NULL;
    channel1->id = channel_id;
    channel1->len =0;
    channel1->next=NULL;
    return channel1;
}

device_file *find_device_in_devices(unsigned int minor){
    device_file *curr_device;
    curr_device = all_devices;
    while(curr_device!=NULL ) {
        if(curr_device->minor==minor) return curr_device;
        curr_device=curr_device->next_device_file;
    }
    return NULL;
}
device_file* register_device(unsigned int minor ){
    device_file *return_device_file;
    device_file *curr_device;
    return_device_file = find_device_in_devices(minor);
    if(return_device_file!=NULL) {
        return return_device_file;
    }
    return_device_file = init_device(minor);
    curr_device = all_devices;
    if(curr_device==NULL) {
        all_devices = return_device_file;
    }
    else {
        while (curr_device->next_device_file!=NULL) {
            curr_device = curr_device->next_device_file;
        }
        curr_device->next_device_file=return_device_file;
    }
    return return_device_file;
}

channel* find_channel_in_device(unsigned int minor, unsigned int channel_id) {
    channel *curr_channel;
    device_file* related_device;
    related_device = find_device_in_devices(minor);
    if(related_device==NULL) {
        return NULL;
    }
    curr_channel = related_device->channels;
    while(curr_channel!=NULL) {
        if (curr_channel->id == channel_id) {
            return curr_channel;
        }
        curr_channel = curr_channel->next;
    }
    return NULL;
}

channel* add_channel(unsigned int minor,unsigned int channel_id){
    device_file *related_device;
    channel *returned_channel;
    channel *curr_channel;
    related_device = find_device_in_devices(minor);
    if(related_device == NULL){return NULL;}
    returned_channel = find_channel_in_device(minor, channel_id);
    if(returned_channel != NULL) {
        return returned_channel;
    }
    returned_channel = init_channel(channel_id);
    if(returned_channel == NULL) return NULL;
    curr_channel = related_device->channels;
    if(curr_channel == NULL ) {
        related_device->channels = returned_channel;
        return returned_channel;
    }
    while(curr_channel->next!=NULL) {curr_channel = curr_channel->next;}
    curr_channel->next=returned_channel;
    return returned_channel;
}


static int device_open(struct inode* inode, struct file* file) {
    device_file *device;
    if(inode==NULL || file==NULL){
        return -EINVAL;
    }
    device = register_device(iminor(inode));
    if(device==NULL) {
        printk("FAILED registering device\n");
        return -ENOMEM;
    }
    return 0;
}


static ssize_t device_read(struct file* file, char __user* buffer, size_t length, loff_t* offset){
unsigned int minor , channel_id;
channel *channel1;
int i;
i=0;
if(file==NULL){
return -EINVAL;
}
if(file->f_inode == NULL){
return -EINVAL;
}
minor = iminor(file->f_inode);
channel_id = (unsigned long) file->private_data;
if(channel_id<=0){return -EINVAL;}
channel1 = find_channel_in_device(minor,channel_id);
if(channel1==NULL){
printk("NO SUCH CHANNEL\n");
return -EINVAL;
}
if(channel1->len==0){
printk("MESSAGE IS EMPTY!\n");
return -EWOULDBLOCK;
}
if(channel1->len > length){
return -ENOSPC;
}
while(i < length && i < channel1->len){
if(put_user(channel1->curr_message[i], &buffer[i])!=0){
return -EFAULT;
}
i++;
}
return i;
}
static ssize_t device_write (struct file* file , const char __user* buffer, size_t length, loff_t* offset){
channel *channel;
unsigned int channel_id;
int i;
i=0;
if(length <= 0 || length>128){
return -EMSGSIZE;
}
if(file==NULL ){
return -EINVAL;
}
if(file->f_inode==NULL){
return -EINVAL;
}
channel_id=(unsigned long)file->private_data;
if (channel_id  <= 0){
return -EINVAL;
}
channel = find_channel_in_device(iminor(file->f_inode),channel_id);
if(channel==NULL){
return -EINVAL;
}
for(i=0;i<length && i<BUFFER_SIZE;i++){
if(get_user(channel->curr_message[i],&buffer[i]) !=0) return -EFAULT;
}
channel->len=length;
return i;
}
static long device_ioctl(struct file* file, unsigned int ioctl_command_id,unsigned long ioctl_param){
    channel* channels;
    if(ioctl_param==0 || ioctl_command_id != MSG_SLOT_CHANNEL) {
        return -EINVAL;
    }
    if(file==NULL){return -EINVAL;}
    channels = add_channel(iminor(file->f_inode),(int) ioctl_param);
    file->private_data = (void * ) ioctl_param;
    if(channels ==NULL){ return -ENOMEM;}
    return 0;
}

static int __init simple_init(void) {
    int rc=-1;
    memset(&device_info, 0, sizeof(chardev_info) );
    spin_lock_init(&device_info.lock);
    rc = register_chrdev(MAJOR_NUM, DEVICE_RANGE_NAME, &Fops );
    if(rc<0) {
        printk( KERN_ERR "%s registration failed for %d\n",DEVICE_RANGE_NAME, MAJOR_NUM);
        return rc;
    }
    return 0;
}


static void __exit simple_cleanup(void)
{
    free_all_devices();
    unregister_chrdev(MAJOR_NUM, DEVICE_RANGE_NAME);
}

module_init(simple_init);
module_exit(simple_cleanup);



