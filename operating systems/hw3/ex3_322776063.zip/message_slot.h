

#ifndef OS_MESSAGE_SLOT_H
#define OS_MESSAGE_SLOT_H

#endif //OS_MESSAGE_SLOT_H
#include <linux/ioctl.h>
#define DEVICE_RANGE_NAME "message_slot"
#define MAJOR_NUM 235
#define BUFFER_SIZE 128
#define MSG_SLOT_CHANNEL _IOW(MAJOR_NUM, 0, unsigned int)

typedef struct channel{
    char curr_message[BUFFER_SIZE];
    unsigned int id;
    int len;
    struct channel* next;
} channel;

typedef struct device_file{
    struct device_file* next_device_file;
    channel* channels;
    unsigned int minor;
} device_file;